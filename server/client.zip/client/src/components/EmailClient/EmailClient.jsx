import { useState, useEffect, useRef } from 'react';
import { CircleUserRound, Send, Inbox, Plus, Menu, X, LogOut, Mail, ShieldCheck, Loader } from 'lucide-react';
import EmailViewer from '../EmailViewer/EmailViewer';

export default function EmailClient() {
  const [activeTab, setActiveTab] = useState('inbox');
  const [composeOpen, setComposeOpen] = useState(false);
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  const [selectedEmail, setSelectedEmail] = useState(null);
  const [isDecrypting, setIsDecrypting] = useState(false);
  const [decryptedEmails, setDecryptedEmails] = useState([]);
  const [isLoggedIn, setIsLoggedIn] = useState(true);
  const [selectedFiles, setSelectedFiles] = useState([]);
  
  const emailContentRef = useRef(null);

  const user = {
    name: "John Doe",
    email: "john.doe@qmail.com"
  };
  
  const emails = {
    inbox: [
      { 
        id: 1, 
        sender: 'Quantum Systems', 
        subject: 'Your Neural Implant Update', 
        time: '09:15', 
        read: false,
        from: "updates@quantumsystems.com",
        to: "john.doe@qmail.com",
        date: "April 12, 2025 09:15 AM",
        body: "This message is encrypted for your security. Please click the decrypt button below to view the contents.",
        encrypted: true,
        decryptedSubject: "Your Neural Implant Update - Important Action Required",
        decryptedBody: "Dear John Doe,\n\nOur systems indicate that your Quantum Neural Implant (Model NS7500) requires a critical security update. This update addresses recently discovered vulnerabilities that could potentially allow unauthorized access to your neural interface.\n\nUpdate details:\n• Version: 12.7.3\n• Security level: Critical\n• Installation time: 4 minutes\n• Neural downtime: 30 seconds\n\nPlease connect to a secure quantum network and initiate the update process within the next 48 hours to ensure your continued protection.\n\nFor assistance, contact our support team at support@quantumsystems.com.\n\nStay secure,\nQuantum Systems Security Team",
        attachments: [
          { name: "Neural_Implant_Update_Guide.pdf", size: "1.2 MB", url: "https://example.com/Neural_Implant_Update_Guide.pdf" },
          { name: "Security_Patch_Notes.txt", size: "45 KB", url: "https://example.com/Security_Patch_Notes.txt" }
        ]
      },
      { 
        id: 2, 
        sender: 'Mars Colony', 
        subject: 'Interplanetary Transfer Update', 
        time: 'Yesterday', 
        read: true,
        from: "transfers@marscolony.gov",
        to: "john.doe@qmail.com",
        date: "April 11, 2025 03:22 PM",
        body: "This message is encrypted for your security. Please click the decrypt button below to view the contents.",
        encrypted: true,
        decryptedBody: "Hello John,\n\nYour application for the Mars Transfer Program has been accepted! We're pleased to inform you that your departure is scheduled for June 15, 2025.\n\nPlease complete the following before your departure date:\n• Medical examination (schedule within next 14 days)\n• Zero-G training (mandatory 3-day course)\n• Personal belongings registration (15kg limit applies)\n\nA detailed information package will arrive in your physical mailbox within 3 business days.\n\nWelcome to the future of humanity!\n\nRegards,\nMars Colony Transfer Department",
        attachments: [
          { name: "Mars_Transfer_Requirements.pdf", size: "3.5 MB", url: "https://example.com/Mars_Transfer_Requirements.pdf" },
          { name: "Medical_Forms.zip", size: "2.1 MB", url: "https://example.com/Medical_Forms.zip" }
        ]
      },
      { 
        id: 3, 
        sender: 'NeuralLink', 
        subject: 'Cloud Mind Backup Complete', 
        time: 'Apr 10', 
        read: true,
        from: "backups@neurallink.io",
        to: "john.doe@qmail.com",
        date: "April 10, 2025 11:45 AM",
        body: "This message is encrypted for your security. Please click the decrypt button below to view the contents.",
        encrypted: true,
        decryptedBody: "Your weekly neural backup has been successfully completed and securely stored in our quantum datacenter. Memory integrity: 99.97%\n\nNo anomalies detected in your cognitive patterns.\n\nYou have used 67% of your premium storage allocation. Would you like to upgrade your plan?\n\nThank you for trusting NeuralLink with your most precious data."
      },
      { 
        id: 4, 
        sender: 'AI Assistant', 
        subject: 'Weekly Summary Report', 
        time: 'Apr 9', 
        read: true,
        from: "your-assistant@ai-systems.com",
        to: "john.doe@qmail.com",
        date: "April 9, 2025 08:00 AM",
        body: "This message is encrypted for your security. Please click the decrypt button below to view the contents.",
        encrypted: true,
        decryptedBody: "Hello John,\n\nHere's your weekly summary:\n\n• Productivity: 87% (↑3% from last week)\n• Sleep quality: 92% (↑5%)\n• Exercise goals: 4/5 achieved\n• Calendar: 3 important meetings tomorrow\n• Smart home: Energy usage optimized, saved 12%\n\nIt looks like you're making excellent progress on Project Aurora. Would you like me to allocate more focus time for this in your schedule next week?\n\nYour AI Assistant"
      },
      { 
        id: 5, 
        sender: 'Orbital Station', 
        subject: 'Shuttle Departure Scheduled', 
        time: 'Apr 8', 
        read: true,
        from: "departures@orbital-tourism.space",
        to: "john.doe@qmail.com",
        date: "April 8, 2025 02:15 PM",
        body: "This message is encrypted for your security. Please click the decrypt button below to view the contents.",
        encrypted: true,
        decryptedBody: "Dear Valued Passenger,\n\nYour orbital vacation package has been confirmed!\n\nDeparture: April 30, 2025 at 08:30 AM (local time)\nCheck-in: 3 hours before departure\nLocation: Pacific Spaceport, Terminal E\n\nYour 3-day orbital package includes:\n• Luxury suite with Earth view\n• Zero-gravity experience sessions\n• Gourmet meals by our star chef\n• Spacewalk (optional, additional fee applies)\n\nPlease remember to complete your space readiness training online before arrival.\n\nWe look forward to providing you with an unforgettable journey among the stars!\n\nOrbital Tourism Team"
      },
    ],
    sent: [
      { 
        id: 6, 
        recipient: 'Deep Space Mining', 
        subject: 'Resource Extraction Agreement', 
        time: 'Today',
        from: "john.doe@qmail.com", 
        to: "contracts@deepspacemining.com",
        date: "April 12, 2025 10:30 AM",
        body: "This message is encrypted for your security. Please click the decrypt button below to view the contents.",
        encrypted: true,
        decryptedBody: "To whom it may concern,\n\nAfter reviewing your proposal, I am pleased to accept the terms of the asteroid mining contract. The revenue sharing model of 60/40 is acceptable with the following conditions:\n\n1. Initial equipment investment will be amortized over 5 years\n2. First right of refusal on rare earth elements discovered\n3. Quarterly reporting on extraction volumes\n\nPlease prepare the final contract for digital signature by Monday.\n\nRegards,\nJohn Doe\nInvestment Director",
        attachments: [
          { name: "Contract_Review.pdf", size: "1.8 MB", url: "https://example.com/Contract_Review.pdf" },
          { name: "Financial_Projections.xlsx", size: "2.3 MB", url: "https://example.com/Financial_Projections.xlsx" }
        ]
      },
      { 
        id: 7, 
        recipient: 'Neural Networks Inc', 
        subject: 'Consciousness Upload Request', 
        time: 'Apr 10',
        from: "john.doe@qmail.com", 
        to: "services@neuralnetworks.corp",
        date: "April 10, 2025 09:45 AM",
        body: "This message is encrypted for your security. Please click the decrypt button below to view the contents.",
        encrypted: true,
        decryptedBody: "Hello,\n\nI would like to schedule a consultation for your Partial Consciousness Upload program. I'm particularly interested in the knowledge retention package rather than the full personality simulation.\n\nMy primary goal is to create a teaching assistant version of myself to help with my research while I'm occupied with other projects.\n\nDo you currently have any openings in the next month? I've already completed the preliminary neural mapping at your downtown clinic.\n\nThank you,\nJohn Doe"
      },
      { 
        id: 8, 
        recipient: 'Quantum Security', 
        subject: 'Encryption Protocol Upgrade', 
        time: 'Apr 7',
        from: "john.doe@qmail.com",
        to: "support@quantumsecurity.net",
        date: "April 7, 2025 04:20 PM",
        body: "This message is encrypted for your security. Please click the decrypt button below to view the contents.",
        encrypted: true,
        decryptedBody: "Security Team,\n\nI'd like to upgrade my personal encryption protocol to your latest quantum-resistant algorithm. My current implementation is QS-256, but I understand you've released QS-512 with improved entanglement protection.\n\nAdditionally, please authorize my new neural implant (Model: NS7500) for secure authentication.\n\nPlease confirm the upgrade costs and schedule.\n\nBest regards,\nJohn Doe\nPremium Security Client"
      },
    ],
  };

  // Toggle user menu
  const toggleUserMenu = () => {
    setUserMenuOpen(!userMenuOpen);
  };
  
  // Close user menu when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (userMenuOpen && !event.target.closest('.user-menu-container')) {
        setUserMenuOpen(false);
      }
    };
    
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [userMenuOpen]);

  // Prevent back navigation after logout
  useEffect(() => {
    if (!isLoggedIn) {
      // Replace the current history entry to prevent going back
      window.history.replaceState(null, '', '/');
      
      // Add an event listener for the popstate event to handle back button
      const handlePopState = (e) => {
        // If user tries to navigate back after logout, redirect to root
        if (!isLoggedIn) {
          window.history.pushState(null, '', '/');
        }
      };
      
      window.addEventListener('popstate', handlePopState);
      
      return () => {
        window.removeEventListener('popstate', handlePopState);
      };
    }
  }, [isLoggedIn]);

  // Handle logout
  const handleLogout = () => {
    // Show loading state if needed
    
    // Perform logout actions
    setTimeout(() => {
      setIsLoggedIn(false);
      
      // Redirect to root
      window.location.href = '/';
    }, 500);
  };

  // Check if email has been decrypted before
  const isEmailDecrypted = (emailId) => {
    return decryptedEmails.includes(emailId);
  };

  const handleDecrypt = () => {
    setIsDecrypting(true);
    
    setTimeout(() => {
      // Add this email to the list of decrypted emails
      if (!isEmailDecrypted(selectedEmail.id)) {
        setDecryptedEmails([...decryptedEmails, selectedEmail.id]);
      }
      
      // Update the selected email
      const updatedEmail = {
        ...selectedEmail,
        body: selectedEmail.decryptedBody,
        subject: selectedEmail.decryptedSubject || selectedEmail.subject,
        encrypted: false
      };
      
      setSelectedEmail(updatedEmail);
      setIsDecrypting(false);
    }, 2000);
  };

  const markAsRead = (emailId) => {
    const updatedEmails = {
      ...emails,
      inbox: emails.inbox.map(email => 
        email.id === emailId ? { ...email, read: true } : email
      )
    };
    // In a real app, you would update the state here
  };

  const tabContent = {
    inbox: () => (
      <div className="space-y-1">
        {emails.inbox.map(email => (
          <EmailItem 
            key={email.id} 
            primary={email.sender}
            secondary={email.subject}
            time={email.time}
            read={email.read}
            onClick={() => {
              markAsRead(email.id);
              setSelectedEmail(email);
            }}
          />
        ))}
      </div>
    ),
    sent: () => (
      <div className="space-y-1">
        {emails.sent.map(email => (
          <EmailItem 
            key={email.id} 
            primary={`To: ${email.recipient}`}
            secondary={email.subject}
            time={email.time}
            read={true}
            onClick={() => setSelectedEmail(email)}
          />
        ))}
      </div>
    ),
  };

  // Show login page if logged out
  if (!isLoggedIn) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center p-4">
        <div className="bg-gray-900 rounded-lg shadow-2xl w-full max-w-md p-8 border border-gray-800">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-blue-400 tracking-wider">Q<span className="text-purple-400">MAIL</span></h1>
            <p className="text-gray-400 mt-2">Quantum-secure communication</p>
          </div>
          
          <div className="space-y-6">
            <div className="space-y-2">
              <label className="text-gray-300 block">Email</label>
              <input 
                type="email" 
                className="w-full bg-gray-800 border border-gray-700 rounded-lg p-3 text-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="your.email@qmail.com"
              />
            </div>
            
            <div className="space-y-2">
              <label className="text-gray-300 block">Password</label>
              <input 
                type="password" 
                className="w-full bg-gray-800 border border-gray-700 rounded-lg p-3 text-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="••••••••••••"
              />
            </div>
            
            <div className="pt-2">
              <button className="w-full bg-gradient-to-r from-blue-600 to-purple-600 text-white py-3 rounded-lg hover:opacity-90 transition-opacity shadow-lg">
                Sign In
              </button>
            </div>
            
            <div className="text-center text-gray-500 text-sm">
              <p>Don't have an account? <a href="#" className="text-blue-400 hover:underline">Create one</a></p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black text-gray-100 flex flex-col">
      {/* Top Navigation Bar */}
      <nav className="bg-gray-900 border-b border-gray-800 p-4 flex items-center justify-between relative">
        <div className="flex items-center">
          <button 
            onClick={() => setMobileNavOpen(!mobileNavOpen)}
            className="md:hidden mr-4 text-gray-400 hover:text-white"
          >
            <Menu size={24} />
          </button>
          <span className="text-xl font-semibold text-blue-400 tracking-wider">Q<span className="text-purple-400">MAIL</span></span>
        </div>
        
        <div className="hidden md:flex items-center space-x-8">
          <NavButton 
            icon={<Inbox size={20} />} 
            label="Inbox" 
            active={activeTab === 'inbox'} 
            onClick={() => setActiveTab('inbox')} 
            count={emails.inbox.filter(e => !e.read).length}
          />
          <NavButton 
            icon={<Send size={20} />} 
            label="Sent" 
            active={activeTab === 'sent'} 
            onClick={() => setActiveTab('sent')} 
          />
        </div>
        
        <div className="flex items-center space-x-4 user-menu-container">
          <button 
            onClick={toggleUserMenu}
            className="rounded-full bg-gray-800 p-2 text-gray-400 hover:text-white hover:bg-gray-700 transition-colors"
            aria-expanded={userMenuOpen}
            aria-haspopup="true"
          >
            <CircleUserRound size={24} /> 
          </button>
          
          {/* User Popup Menu */}
          {userMenuOpen && (
            <div className="absolute right-4 top-16 w-64 bg-gray-800 rounded-lg shadow-lg overflow-hidden z-50">
              <div className="p-4 border-b border-gray-700">
                <div className="flex items-center space-x-3">
                  <div className="bg-blue-500 rounded-full p-2">
                    <CircleUserRound size={24} className="text-white" />
                  </div>
                  <div>
                    <p className="text-white font-medium">{user.name}</p>
                    <p className="text-gray-400 text-sm">{user.email}</p>
                  </div>
                </div>
              </div>
              
              <div>
                <button 
                  onClick={handleLogout}
                  className="w-full text-left px-4 py-3 text-gray-300 hover:bg-gray-700 flex items-center space-x-2 transition-colors"
                >
                  <LogOut size={18} />
                  <span>Log out</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </nav>

      {/* Mobile Navigation Menu */}
      {mobileNavOpen && (
        <div className="md:hidden bg-gray-900 border-b border-gray-800">
          <div className="p-2 flex flex-col">
            <button 
              className={`p-3 text-left flex items-center ${activeTab === 'inbox' ? 'bg-gray-800 text-blue-400' : 'text-gray-400'} rounded-lg`}
              onClick={() => {
                setActiveTab('inbox');
                setMobileNavOpen(false);
              }}
            >
              <Inbox size={20} className="mr-3" />
              <span>Inbox</span>
              {emails.inbox.filter(e => !e.read).length > 0 && (
                <span className="ml-auto bg-blue-500 text-xs rounded-full px-2 py-1">
                  {emails.inbox.filter(e => !e.read).length}
                </span>
              )}
            </button>
            
            <button 
              className={`p-3 text-left flex items-center ${activeTab === 'sent' ? 'bg-gray-800 text-blue-400' : 'text-gray-400'} rounded-lg`}
              onClick={() => {
                setActiveTab('sent');
                setMobileNavOpen(false);
              }}
            >
              <Send size={20} className="mr-3" />
              <span>Sent</span>
            </button>
            
            <div className="border-t border-gray-800 mt-2 pt-2">
              <button 
                className="p-3 text-left flex items-center text-gray-400 rounded-lg"
                onClick={handleLogout}
              >
                <LogOut size={20} className="mr-3" />
                <span>Sign out</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Main Content */}
      <div className="flex flex-1 overflow-hidden">
        <main className="flex-1 flex flex-col p-4 overflow-hidden">
          {/* Section Header */}
          <div className="flex items-center justify-between mb-4">
            <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent">
              {activeTab.charAt(0).toUpperCase() + activeTab.slice(1)}
            </h1>
            <button 
              onClick={() => setComposeOpen(true)}
              className="bg-gradient-to-r from-blue-600 to-purple-600 text-white px-4 py-2 rounded-lg flex items-center hover:opacity-90 transition-opacity shadow-lg shadow-blue-900/20"
            >
              <Plus size={18} className="mr-2" />
              Compose
            </button>
          </div>
          
          {/* Email List */}
          <div className="overflow-y-auto flex-1 pr-1 custom-scrollbar">
            {tabContent[activeTab]()}
          </div>
        </main>
      </div>

      {/* Email Viewer Modal */}
      {selectedEmail && (
        <div className="fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center p-4 z-50">
          <EmailViewer 
            email={selectedEmail}
            onClose={() => setSelectedEmail(null)}
          />
        </div>
      )}
  
      {composeOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center p-4 z-50">
          <div className="bg-gray-900 border border-gray-800 rounded-lg shadow-2xl w-full max-w-2xl overflow-hidden">
            <div className="flex justify-between items-center border-b border-gray-800 p-4">
              <h2 className="text-xl font-semibold text-blue-400">New Message</h2>
              <button 
                onClick={() => setComposeOpen(false)}
                className="text-gray-400 hover:text-white"
              >
                <X size={24} />
              </button>
            </div>
            
            <div className="p-4 space-y-4">
              <div className="flex items-center space-x-2 border-b border-gray-800 pb-2">
                <span className="text-gray-500">To:</span>
                <input 
                  type="text" 
                  className="flex-1 bg-transparent focus:outline-none text-gray-300" 
                  placeholder="recipients@example.com"
                />
              </div>
              
              <div className="flex items-center space-x-2 border-b border-gray-800 pb-2">
                <span className="text-gray-500">Subject:</span>
                <input 
                  type="text" 
                  className="flex-1 bg-transparent focus:outline-none text-gray-300" 
                  placeholder="Type subject here"
                />
              </div>
              
              <textarea 
                className="w-full h-64 bg-gray-900 border border-gray-800 rounded-lg p-3 focus:outline-none focus:border-blue-500 text-gray-300 resize-none"
                placeholder="Compose your message..."
              ></textarea>
              
              <div className="flex flex-col space-y-2">
                <div className="flex items-center space-x-2">
                  <label className="px-4 py-2 border border-gray-700 text-gray-300 rounded-lg hover:bg-gray-800 transition-colors cursor-pointer">
                    <input 
                      type="file" 
                      className="hidden" 
                      multiple
                      onChange={(e) => {
                        const files = Array.from(e.target.files);
                        setSelectedFiles([...selectedFiles, ...files]);
                      }}
                    />
                    Attach Files
                  </label>
                  {selectedFiles.length > 0 && (
                    <span className="text-sm text-gray-400">
                      {selectedFiles.length} file{selectedFiles.length !== 1 ? 's' : ''} selected
                    </span>
                  )}
                </div>
                
                {selectedFiles.length > 0 && (
                  <div className="bg-gray-800 rounded-lg p-3 space-y-2">
                    {selectedFiles.map((file, index) => (
                      <div key={index} className="flex items-center justify-between text-sm text-gray-300">
                        <span className="truncate">{file.name}</span>
                        <button 
                          onClick={() => {
                            const newFiles = [...selectedFiles];
                            newFiles.splice(index, 1);
                            setSelectedFiles(newFiles);
                          }}
                          className="text-gray-400 hover:text-white"
                        >
                          <X size={16} />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
              
              <div className="flex justify-between items-center">
                <div className="flex items-center text-gray-400">
                  <ShieldCheck size={16} className="text-green-400 mr-1" />
                  <span className="text-sm">End-to-end encrypted</span>
                </div>
                
                <div className="flex space-x-3">
                  <button 
                    onClick={() => setComposeOpen(false)}
                    className="px-4 py-2 border border-gray-700 text-gray-300 rounded-lg hover:bg-gray-800 transition-colors"
                  >
                    Cancel
                  </button>
                  <button className="px-4 py-2 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-lg hover:opacity-90 transition-opacity">
                    Send Message
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// Component for a navigation button
function NavButton({ icon, label, active, onClick, count }) {
  return (
    <button 
      onClick={onClick}
      className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-colors ${
        active 
          ? 'text-blue-400 bg-gray-800' 
          : 'text-gray-400 hover:text-gray-200 hover:bg-gray-800'
      }`}
    >
      {icon}
      <span>{label}</span>
      {count > 0 && (
        <span className={`text-xs rounded-full px-2 py-0.5 ${active ? 'bg-blue-500' : 'bg-gray-700'}`}>
          {count}
        </span>
      )}
    </button>
  );
}

function EmailItem({ primary, secondary, time, read, onClick }) {
  return (
    <div 
      className={`flex items-center p-3 rounded-lg cursor-pointer ${
        read ? 'text-gray-400' : 'text-white font-medium'
      } hover:bg-gray-900`}
      onClick={onClick}
    >      
      <div className="flex-1 min-w-0">
        <div className="flex justify-between">
          <span className={`truncate ${read ? '' : 'text-white font-medium'}`}>{primary}</span>
          <span className="text-xs text-gray-500 ml-2 whitespace-nowrap">{time}</span>
        </div>
        <div className="flex items-center">
          <p className="truncate text-sm">{secondary}</p>
        </div>
      </div>
    </div>
  );
}